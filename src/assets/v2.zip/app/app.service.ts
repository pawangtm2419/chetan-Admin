import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

interface DataServe {
  serverData: Array<object>;
}

interface LoginData {
  success: boolean;
  serect: string;
  login: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(public http: HttpClient, public router: Router) { }

  getStatusDetail() {
    return this.http.get<DataServe>('http://127.0.0.1/seat/seatStatus.php');
  }

  statusUpdate(seatNumber: any, seatStatus: any) {
    return this.http.post<LoginData>('http://127.0.0.1/seat/updateStatus.php', {
      seatNumber, seatStatus
    });
  }

  insertNewSeat(seatNumber: string) {
    return this.http.post<LoginData>('http://127.0.0.1/seat/seatInsert.php', {
      seatNumber
    });
  }
}
