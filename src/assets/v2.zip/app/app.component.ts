import { Component, OnInit } from '@angular/core';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Wellcome';
  seatData: any;
  error: any;
  maping: any;
  filtering: any;
  count: any;
  avilableSeat = 0;

  constructor(private service: AppService) { }

  ngOnInit(): void {
    this.service.getStatusDetail().subscribe(res => {
      this.count = Object.values(res);
      this.maping = this.count.map(function(data) { 
        return (data['seat_status'] == 0 ? data : null);
      });
      this.filtering = this.maping.filter(function(data) {
        return data;
      });
    },
      (err) => {
        this.error = err;
      }
    );
  }

  update(seatNumber, seatStatus) {
    this.service.statusUpdate(seatNumber, seatStatus).subscribe(data => {
      if (data.success) {
        window.alert(data.serect);
        this.ngOnInit();
      } else {
        window.alert(data.serect);
      }
    });
  }

  insertSeat(event: any) {
    let seatNumber = (<HTMLInputElement>document.getElementById('seatNumber')).value;
    this.service.insertNewSeat(seatNumber).subscribe(data => {
      if (data.success) {
        console.log(data.serect);
      } else {
        window.alert(data.serect);
      }
    });
  }
}
