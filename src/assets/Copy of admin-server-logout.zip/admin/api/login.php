<?php
    include_once 'db.php';
    session_start();
    $_POST = json_decode(file_get_contents('php://input'), true);
    
    if(isset($_POST) && !empty($_POST)) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        $sql = "SELECT `username` FROM `chetan` WHERE `username` = '$username' AND `password` = '$password'";
        $result = mysqli_query($conn,$sql);
        
        if ($result->num_rows == 1) {
            $_SESSION['is_login'] = true;
            $_SESSION['username'] = $username;
            ?>
                {"success":true, "serect":"This is Correct"}
            <?php
        } 
        else 
        {
            ?>
                {"success":false, "serect":"This is Incorrect"}
            <?php
        }
    }
   else {
        ?>
            {"success":false, "serect":"Only Post"}
        <?php
    }
?>