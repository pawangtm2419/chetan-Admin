<?php
include_once 'db.php';
session_start();
    if($_SESSION['is_login']){
        $username = $_SESSION['username'];
    }
    else{
        header('location:https://chetanclinic.com/admin');
    }
$data = [];
$sql = "SELECT `title`,`description`,`categoryid`,`image`,`bloglink` FROM `blog` ORDER BY id DESC";

$result = mysqli_query($conn,$sql); 

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    print '{"serverData": ';
    print json_encode( $data);
    print '}';
} 
else 
{
    echo "0 results";
}
?>
