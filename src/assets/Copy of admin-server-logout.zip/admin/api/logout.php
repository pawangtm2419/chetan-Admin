<?php

include_once 'db.php';

session_start();
    if($_SESSION['is_login']){
        unset($_SESSION);
        session_destroy();
        $_SESSION['is_login'] = false;
    }
    else{
        header('location:https://chetanclinic.com/admin');
    }

?>

{
   "success": true,
   "message": "You are successfully Loggrd out."
} 
