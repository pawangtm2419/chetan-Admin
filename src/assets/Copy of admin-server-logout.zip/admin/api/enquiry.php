<?php
include_once 'db.php';
session_start();
    if($_SESSION['is_login']){
        $username = $_SESSION['username'];
    }
    else{
        header('location:https://chetanclinic.com/admin');
    }
$enquirydata = [];
$sql = "SELECT `name`, `email`,`number`,`disease` FROM `msglist` ORDER BY id DESC";

$result = mysqli_query($conn,$sql); 

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $enquirydata[] = $row;
    }
    print '{"serverData": ';
    print json_encode( $enquirydata);
    print '}';
} 
else 
{
    echo "0 results";
}
?>
