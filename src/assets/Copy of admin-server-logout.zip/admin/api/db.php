<?php
header('Access-Control-Allow-Origin: *');

header('Access-Control-Allow-Headers: *');

header('Content-Type: application/json');

$servername = "localhost";
$username   = "bookap";
$password   = "JaiSaiRam9";
$dbname     = "bookap";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>