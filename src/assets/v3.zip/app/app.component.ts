import { Component, OnInit } from '@angular/core';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Wellcome';
  seatData: any;
  error: any;
  maping: any;
  filtering: any;
  count: any;
  avilableSeat = 0;

  constructor(private service: AppService) { }

  ngOnInit(): void {
    this.service.getStatusDetail().subscribe(res => {
      this.count = Object.values(res);
      this.maping = this.count.map(function (data: { [x: string]: number; }) {
        return (data['seat_status'] == 0 ? data : null);
      });
      this.filtering = this.maping.filter(function (data: any) {
        return data;
      });
    },
      (err) => {
        this.error = err;
      }
    );
  }

  searchSeat(event: any) {
    let seatNumber = ((<HTMLInputElement>document.getElementById('seatNumber')).value);
    let l = this.filtering.length;
    if(l < seatNumber) {
      window.alert(seatNumber+' seats are not avilable!');
    } else if(l == seatNumber) {
      window.alert(seatNumber+' seats are avilable and seats will be full!');
    } else {
      let seats = this.filtering.map(function (data) {
        return data['seat_number'];
      }).map(x=>+x);
      let data = this.searchAvilSeat(seats, seatNumber);
      console.log(data);
    }
    }
    searchAvilSeat(seats: any, seatNumber) {
      let a = [];
      for(let i=0; i<=seats.length; i++) {
        a.push(seats[i]-seats[i+1]);
      }
      return (a.sort((a,b) => b-a)).filter(function(data) { return data;});
    }

  update(seatNumber: any, seatStatus: any) {
    this.service.statusUpdate(seatNumber, seatStatus).subscribe(data => {
      if (data.success) {
        window.alert(data.serect);
        this.ngOnInit();
      } else {
        window.alert(data.serect);
      }
    });
  }

  insertSeat(event: any) {
    let seatNumber = (<HTMLInputElement>document.getElementById('seatNumber')).value;
    this.service.insertNewSeat(seatNumber).subscribe(data => {
      if (data.success) {
        console.log(data.serect);
      } else {
        window.alert(data.serect);
      }
    });
  }
}
