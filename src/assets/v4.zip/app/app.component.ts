import { Component, OnInit } from '@angular/core';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  ngOnInit() {
    for(let i = 1; i <= 100; i++) {
      var number = i;
      if(number%15 == 0) {
        console.log("Pawan Gautam");
      } else if( number%5 == 0) {
        console.log("Gautam");
      } else if (number%3 == 0) {
        console.log("Pawan");
      } else {
      console.log(number);  
      }  
    } 
  }
 
}
