import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SeatStatusComponent } from './seat-status.component';

describe('SeatStatusComponent', () => {
  let component: SeatStatusComponent;
  let fixture: ComponentFixture<SeatStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SeatStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SeatStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
