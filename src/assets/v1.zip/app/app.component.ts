import { Component } from '@angular/core';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Wellcome';
  seatData: any;
  error: any;
  constructor(private service: AppService) { }

  insertSeat(event: any) {
    let seatNumber = (<HTMLInputElement>document.getElementById('seatNumber')).value;
    this.service.insertNewSeat(seatNumber).subscribe(data => {
      if (data.success) {
        console.log(data.serect);
      } else {
        window.alert(data.serect);
      }
    });
  }
}
